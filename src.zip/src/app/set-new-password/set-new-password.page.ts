import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-set-new-password',
  templateUrl: './set-new-password.page.html',
  styleUrls: ['./set-new-password.page.scss'],
})
export class SetNewPasswordPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
