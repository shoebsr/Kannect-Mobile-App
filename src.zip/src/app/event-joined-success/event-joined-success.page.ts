import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-event-joined-success',
  templateUrl: './event-joined-success.page.html',
  styleUrls: ['./event-joined-success.page.scss'],
})
export class EventJoinedSuccessPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
