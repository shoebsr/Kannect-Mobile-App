import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tracker-no-tasks',
  templateUrl: './tracker-no-tasks.page.html',
  styleUrls: ['./tracker-no-tasks.page.scss'],
})
export class TrackerNoTasksPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
