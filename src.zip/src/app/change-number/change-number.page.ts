import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-change-number',
  templateUrl: './change-number.page.html',
  styleUrls: ['./change-number.page.scss'],
})
export class ChangeNumberPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
