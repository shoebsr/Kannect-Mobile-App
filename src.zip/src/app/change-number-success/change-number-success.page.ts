import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-change-number-success',
  templateUrl: './change-number-success.page.html',
  styleUrls: ['./change-number-success.page.scss'],
})
export class ChangeNumberSuccessPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
