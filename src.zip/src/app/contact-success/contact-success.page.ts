import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contact-success',
  templateUrl: './contact-success.page.html',
  styleUrls: ['./contact-success.page.scss'],
})
export class ContactSuccessPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
