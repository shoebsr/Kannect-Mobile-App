import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-messages',
  templateUrl: './create-messages.page.html',
  styleUrls: ['./create-messages.page.scss'],
})
export class CreateMessagesPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
